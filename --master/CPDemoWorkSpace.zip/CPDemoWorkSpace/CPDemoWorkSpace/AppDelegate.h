//
//  AppDelegate.h
//  CPDemoWorkSpace
//
//  Created by Bruno.ma on 8/2/16.
//  Copyright © 2016 Bruno.ma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

